-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 06, 2018 at 04:04 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zoe_testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `agent_contact`
--

CREATE TABLE `agent_contact` (
  `id` int(10) UNSIGNED NOT NULL,
  `agent_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `distance` double(8,2) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `geo`
--

CREATE TABLE `geo` (
  `id` int(10) UNSIGNED NOT NULL,
  `zip` int(10) UNSIGNED NOT NULL,
  `name_main_city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` int(11) NOT NULL,
  `lon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `geo`
--

INSERT INTO `geo` (`id`, `zip`, `name_main_city`, `lat`, `lon`) VALUES
(1, 544, 'Holtsville', 41, -73),
(2, 605, 'Aguadilla', 18, -67),
(3, 631, 'Castaner', 18, -67),
(4, 636, 'Rosario', 18, -67);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_11_25_190342_create_auth_tables', 1),
(2, '2018_11_26_153137_create_specialty_table', 1),
(3, '2018_11_26_174229_fill_specialty_table', 1),
(4, '2018_11_27_195058_fill_role_table', 1),
(5, '2018_11_28_215512_create_agent_contac_table', 1),
(6, '2018_12_05_211357_create_geo_table', 1),
(7, '2018_12_05_211859_fill_geo_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_home` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`, `file_home`, `created_at`, `updated_at`) VALUES
(1, 'Contact', 'home_contact', NULL, NULL),
(2, 'Agent', 'home_agent', NULL, NULL),
(3, 'Admin', 'home_admin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `specialty`
--

CREATE TABLE `specialty` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `specialty`
--

INSERT INTO `specialty` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Hedge Funds', '2018-12-06 17:23:42', NULL),
(2, 'Financial Planning', '2018-12-06 17:23:42', NULL),
(3, 'Corporate Finance', '2018-12-06 17:23:42', NULL),
(4, 'Commercial Banking', '2018-12-06 17:23:42', NULL),
(5, 'Investment Banking', '2018-12-06 17:23:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `names` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_names` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthday` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `email` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialty_id` int(10) UNSIGNED NOT NULL,
  `lon` double(10,2) NOT NULL,
  `lat` double(10,2) NOT NULL,
  `login_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role_id`, `names`, `last_names`, `gender`, `birthday`, `email`, `zipcode`, `specialty_id`, `lon`, `lat`, `login_verified_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(7, 'pedro', '1', 2, 'Pedro', 'gomez', 'M', '2018-12-06 12:23:53', 'pedro@gmail.com', '605', 3, 50.00, 60.00, NULL, NULL, '2018-12-06 17:23:53', '2018-12-06 17:23:53'),
(8, 'Mario', '1', 2, 'Mario', 'gomez', 'M', '2018-12-06 12:23:53', 'pedro@gmail.com', '605', 3, 51.00, 61.00, NULL, NULL, '2018-12-06 17:23:53', '2018-12-06 17:23:53'),
(9, 'Carlos', '1', 1, 'Carlos', 'gomez', 'M', '2018-12-06 12:23:53', 'pedro@gmail.com', '605', 3, 49.00, 59.00, NULL, NULL, '2018-12-06 17:23:53', '2018-12-06 17:23:53'),
(10, 'Juan', '1', 1, 'Juan', 'gomez', 'M', '2018-12-06 12:23:53', 'pedro@gmail.com', '605', 3, 56.00, 66.00, NULL, NULL, '2018-12-06 17:23:53', '2018-12-06 17:23:53'),
(11, 'Felipe', '1', 1, 'Felipe', 'gomez', 'M', '2018-12-06 12:23:53', 'pedro@gmail.com', '605', 3, 57.00, 67.00, NULL, NULL, '2018-12-06 17:23:53', '2018-12-06 17:23:53'),
(13, 'admin', '$2y$10$MEu1DEz7MxHHqqTsL83AQe1QJ5CMpIWY.lCEk9jyC6Cl5IQw1Bz7m', 3, 'Admin', 'Ad', 'M', '2018-12-06 12:33:27', 'andre@e.com', '605', 0, -67.00, 18.00, NULL, 'db9JMnZYZdQXTUsH75CdORldN3LbXaC4I6qrMEPK8ySBTIj9vjyVp4ws94Sa', '2018-12-06 17:25:00', '2018-12-06 17:25:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agent_contact`
--
ALTER TABLE `agent_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `geo`
--
ALTER TABLE `geo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specialty`
--
ALTER TABLE `specialty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agent_contact`
--
ALTER TABLE `agent_contact`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `geo`
--
ALTER TABLE `geo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `specialty`
--
ALTER TABLE `specialty`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
